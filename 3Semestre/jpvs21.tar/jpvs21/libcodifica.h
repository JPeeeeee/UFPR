#include "libfila.h"

// funcao que gerencia as operacoes necessarias para codificar a mensagem
void coleta_dados_texto_fila (FILE *LivroCifra, FILE *ArquivoChaves, FILE *MensagemSaida, FILE *MensagemEntrada);